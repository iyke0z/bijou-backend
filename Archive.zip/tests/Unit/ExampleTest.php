<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Http\Controllers\AuthController as Auth;
class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     *
     * @return void
     */
//
}
