<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zjf8Ckic58HBgmH3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MLAphLtnZnPF1jDe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hr29wSGfryqFw7Qz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KytLbZdzNg1SkiDE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/create-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sf3Rj3bfjfPJgDyp',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/delete-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2BbYYruKALcuhwNc',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mRoWHLsLKn7Me0Qn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iNaFnNafCNpeh9X3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iT5XiwpEXJeJwOsE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/pay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YznvYQKg3biGHjMB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KO0NyXgwvROTnoUh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/food-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::quSRFqRVCDmTtXAb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/drink-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TuATy2Kir0pPSTs5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/update-prep-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MnjGO5yjKEgEJNEh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GZxZFiuOBxN11tye',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MMKvOJqvST2Wsoqy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cteoz7TqbQAJsiEg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/get-expiration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::seqjnWw1M0HOtXeY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RrAN2F2Z6W54cLDA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cAFGis2dZagRBK6p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H5DuNIn4y2UY3Dw4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NV9tc8UfD6UgZQCS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WNFW7cE9mueK21SE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vt8w1ckBoAnov5oo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qo7Ox1u1i4xd2jXy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aJvV9hGLngP1vBWw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/role/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UuqpIwBYGgH3zRVJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledge/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XL60LXzLT0GyZa0m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jv0mHX5rXQsoJKug',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xuTsAWf05rjGFHYN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uRTSMNqgI5FORy8v',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/upload/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D1dXVOhmCqTZbPcS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::03NaNuKO2XIpxo6t',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wg5x4EtUpI0Q3jvk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::quK8zUMF3GE0dKcC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P5JW8XkyKtGHXqW0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KJ6mX817qxFdNE4x',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AHG7n0sh4dALp8Rn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/available' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1FJcXvkUPr94Q5Py',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XxA4X3zJK68qaxdP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/periodic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u0Klrm6F8NFtlW1V',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/today' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LKpjcgFdch8Pc1MG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/pod' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CRai6bSmdkKlqbXT',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/poc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z0LBQhRFJYIUoLTn',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/expire' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0wZfIHUfkNoOnuj7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a7q1VwSv3XM5dAyJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5Cl1a3SaXyITDLUz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/activate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4OP0BpZAsr6x7FcQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qMjP2ZR6ijI0lmYa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oHvFt6iNplUlzSRz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e6z4wHJjBa566eT3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4CQW2kgweDgcF7W1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jELTJYKSpMOPMlu9',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hhra5OyNCo031Ck5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/deleted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TyYHvAnDTXtFeapn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/sales-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FYpuj4wa78SLSK3F',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/opex-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qxJ7VGvcXDtZPDSI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/debt-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6SxlVRcUeSnFyKPx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/cogs-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hDr5EgyuVBjGBC5E',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/method-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7FWFFyLYGqQqYKsX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/profit-loss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f6MkGlHfMPW2RMSa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UN6VtbU3sYxZ5CPq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6ahCPM1gZhrdOwkO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nbxkkVHRRle4Gcdr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/generate-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::08OsEaWwnO0k3cKd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/transaction-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Lwv8y2KzqJr67Dta',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user-sales-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rJcKfCdjF0vzFMXG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a3izEWSACt14PXsn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/v1/(?|a(?|dmin/update\\-package/([^/]++)(*:51)|ssign/role/([^/]++)(*:77))|user/(?|([^/]++)(*:101)|update/([^/]++)(*:124)|assign/([^/]++)(*:147)|delete/([^/]++)(*:170))|role/delete/([^/]++)(*:199)|p(?|r(?|iviledge/delete/([^/]++)(*:239)|oduct/(?|update/([^/]++)(*:271)|delete/([^/]++)(*:294)|report/(?|([^/]++)(*:320)|all/([^/]++)(*:340))))|urchase/(?|update/([^/]++)(*:377)|de(?|tail/delete/([^/]++)(*:410)|lete/([^/]++)(*:431))))|c(?|ategory/(?|update/([^/]++)(*:472)|delete/([^/]++)(*:495))|ustomer/(?|update/([^/]++)(*:530)|fund/([^/]++)(*:551)|de(?|lete/([^/]++)(*:577)|tails/([^/]++)(*:599))))|discount/(?|update/([^/]++)(*:637)|delete/([^/]++)(*:660)|customer/(?|([^/]++)(*:688)|delete/([^/]++)/([^/]++)(*:720)))|business/(?|update/([^/]++)(*:757)|delete/([^/]++)(*:780))|expenditure/(?|type/(?|update/([^/]++)(*:827)|delete/([^/]++)(*:850))|update/([^/]++)(*:874)|delete/([^/]++)(*:897))))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RE8zwkwSzTzSPFNL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      77 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WHMHSP3D2SDioROO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YqcR301GEr2Su9wr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      124 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OkyvY6O6Jjtp0GL4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RUDZKOEDArBuUTIb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gC7DQd7rMcw4XhCA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      199 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TdgqeR5f9y76uXrw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      239 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3PJYr6kAD00uim4X',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      271 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LmqDeV0bSiVI5p0a',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      294 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rBXvax6kIHCd9vlE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      320 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pZJWuIKjVBh9DvYq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KHd65R8sz7Z9wt3J',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8162C5Nsvn442Oes',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d8Eo2d9CKAW7Pkzs',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wk6dgUvUBHl0Gbzd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      472 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uwzsmeu9ZIqhCJPJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      495 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SEjvcnEbl23S9Tjw',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      530 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hDvwCwfKGIVz9r3S',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      551 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::41jvSWfEG6vloGw1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oONy0tEIIWsbpTGJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      599 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JO3M6lXjt4I1cJO3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m0walncr8tO5jD2W',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fsu0R6iW2rOBRQEz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      688 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hZhskHWsCyJ7o95n',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      720 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9RFvYxZoYnmh0xL6',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'discount',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      757 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nXzNhE8gTxO8l1ju',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KNSObPolnG5GRdoj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      827 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7f3KrGFtV5v3UDfo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tVn51eRE5uRrU9Pj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      874 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i7EhXmTCMjtirvXT',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      897 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nwj5jB5ptv7lJBbD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::zjf8Ckic58HBgmH3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::zjf8Ckic58HBgmH3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MLAphLtnZnPF1jDe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007c00000000000000000";}";s:4:"hash";s:44:"LAzIQ4V+KGG/8Sp8T8c2+1oQJlPsxSETe1WPZp6cieQ=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::MLAphLtnZnPF1jDe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hr29wSGfryqFw7Qz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'controller' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::hr29wSGfryqFw7Qz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KytLbZdzNg1SkiDE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::KytLbZdzNg1SkiDE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sf3Rj3bfjfPJgDyp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/create-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Sf3Rj3bfjfPJgDyp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RE8zwkwSzTzSPFNL' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/update-package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::RE8zwkwSzTzSPFNL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2BbYYruKALcuhwNc' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/delete-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::2BbYYruKALcuhwNc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mRoWHLsLKn7Me0Qn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sell',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sell',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::mRoWHLsLKn7Me0Qn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iNaFnNafCNpeh9X3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::iNaFnNafCNpeh9X3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iT5XiwpEXJeJwOsE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'controller' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::iT5XiwpEXJeJwOsE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YznvYQKg3biGHjMB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@pay',
        'controller' => 'App\\Http\\Controllers\\TransactionController@pay',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::YznvYQKg3biGHjMB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KO0NyXgwvROTnoUh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::KO0NyXgwvROTnoUh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::quSRFqRVCDmTtXAb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/food-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::quSRFqRVCDmTtXAb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TuATy2Kir0pPSTs5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/drink-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::TuATy2Kir0pPSTs5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MnjGO5yjKEgEJNEh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/update-prep-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::MnjGO5yjKEgEJNEh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GZxZFiuOBxN11tye' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_products',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_products',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::GZxZFiuOBxN11tye',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MMKvOJqvST2Wsoqy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'controller' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::MMKvOJqvST2Wsoqy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cteoz7TqbQAJsiEg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/banks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'controller' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Cteoz7TqbQAJsiEg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::seqjnWw1M0HOtXeY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/get-expiration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'controller' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::seqjnWw1M0HOtXeY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RrAN2F2Z6W54cLDA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/business/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@show_business',
        'controller' => 'App\\Http\\Controllers\\AuthController@show_business',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::RrAN2F2Z6W54cLDA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cAFGis2dZagRBK6p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::cAFGis2dZagRBK6p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H5DuNIn4y2UY3Dw4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:606:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:387:"function (\\Illuminate\\Http\\Request $request) {
            $user = \\App\\Models\\User::with(\'role\')
            // ->with(\'purchase\')
            // ->with(\'sales\')
            ->with(\'access_log\')
            ->with(\'access_code\')
            // ->with(\'expenditure_types\')
            // ->with(\'expenditure\')
            ->find($request->user()->id);
            return $user;
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007d90000000000000000";}";s:4:"hash";s:44:"9vq/Ezpxj9d75Xk+jklnMmzsu62jEN811by2paK0T9M=";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::H5DuNIn4y2UY3Dw4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NV9tc8UfD6UgZQCS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::NV9tc8UfD6UgZQCS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WNFW7cE9mueK21SE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_user',
        'controller' => 'App\\Http\\Controllers\\UserController@create_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::WNFW7cE9mueK21SE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YqcR301GEr2Su9wr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@get_user',
        'controller' => 'App\\Http\\Controllers\\UserController@get_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::YqcR301GEr2Su9wr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OkyvY6O6Jjtp0GL4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update_user',
        'controller' => 'App\\Http\\Controllers\\UserController@update_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::OkyvY6O6Jjtp0GL4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RUDZKOEDArBuUTIb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/assign/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::RUDZKOEDArBuUTIb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gC7DQd7rMcw4XhCA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_user',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::gC7DQd7rMcw4XhCA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vt8w1ckBoAnov5oo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_users',
        'controller' => 'App\\Http\\Controllers\\UserController@all_users',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::vt8w1ckBoAnov5oo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qo7Ox1u1i4xd2jXy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_roles',
        'controller' => 'App\\Http\\Controllers\\UserController@all_roles',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::qo7Ox1u1i4xd2jXy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aJvV9hGLngP1vBWw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/priviledges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'controller' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::aJvV9hGLngP1vBWw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UuqpIwBYGgH3zRVJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_role',
        'controller' => 'App\\Http\\Controllers\\UserController@create_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::UuqpIwBYGgH3zRVJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TdgqeR5f9y76uXrw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_role',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::TdgqeR5f9y76uXrw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XL60LXzLT0GyZa0m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::XL60LXzLT0GyZa0m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3PJYr6kAD00uim4X' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::3PJYr6kAD00uim4X',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WHMHSP3D2SDioROO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/assign/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::WHMHSP3D2SDioROO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jv0mHX5rXQsoJKug' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::jv0mHX5rXQsoJKug',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uwzsmeu9ZIqhCJPJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::uwzsmeu9ZIqhCJPJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SEjvcnEbl23S9Tjw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::SEjvcnEbl23S9Tjw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xuTsAWf05rjGFHYN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::xuTsAWf05rjGFHYN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uRTSMNqgI5FORy8v' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::uRTSMNqgI5FORy8v',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LmqDeV0bSiVI5p0a' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/product/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::LmqDeV0bSiVI5p0a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rBXvax6kIHCd9vlE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::rBXvax6kIHCd9vlE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pZJWuIKjVBh9DvYq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::pZJWuIKjVBh9DvYq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KHd65R8sz7Z9wt3J' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::KHd65R8sz7Z9wt3J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D1dXVOhmCqTZbPcS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/upload/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'controller' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::D1dXVOhmCqTZbPcS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::03NaNuKO2XIpxo6t' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::03NaNuKO2XIpxo6t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8162C5Nsvn442Oes' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::8162C5Nsvn442Oes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d8Eo2d9CKAW7Pkzs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/detail/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::d8Eo2d9CKAW7Pkzs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wk6dgUvUBHl0Gbzd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::Wk6dgUvUBHl0Gbzd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wg5x4EtUpI0Q3jvk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::wg5x4EtUpI0Q3jvk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::quK8zUMF3GE0dKcC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::quK8zUMF3GE0dKcC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P5JW8XkyKtGHXqW0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::P5JW8XkyKtGHXqW0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hDvwCwfKGIVz9r3S' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::hDvwCwfKGIVz9r3S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::41jvSWfEG6vloGw1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/fund/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::41jvSWfEG6vloGw1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oONy0tEIIWsbpTGJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::oONy0tEIIWsbpTGJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JO3M6lXjt4I1cJO3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'controller' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::JO3M6lXjt4I1cJO3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KJ6mX817qxFdNE4x' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::KJ6mX817qxFdNE4x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m0walncr8tO5jD2W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::m0walncr8tO5jD2W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Fsu0R6iW2rOBRQEz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::Fsu0R6iW2rOBRQEz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hZhskHWsCyJ7o95n' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::hZhskHWsCyJ7o95n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AHG7n0sh4dALp8Rn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::AHG7n0sh4dALp8Rn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1FJcXvkUPr94Q5Py' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount/available',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::1FJcXvkUPr94Q5Py',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9RFvYxZoYnmh0xL6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/delete/{id}/{discount}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::9RFvYxZoYnmh0xL6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XxA4X3zJK68qaxdP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/sell/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::XxA4X3zJK68qaxdP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u0Klrm6F8NFtlW1V' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/periodic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::u0Klrm6F8NFtlW1V',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LKpjcgFdch8Pc1MG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/today',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::LKpjcgFdch8Pc1MG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CRai6bSmdkKlqbXT' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/pod',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::CRai6bSmdkKlqbXT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z0LBQhRFJYIUoLTn' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/poc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::Z0LBQhRFJYIUoLTn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nXzNhE8gTxO8l1ju' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::nXzNhE8gTxO8l1ju',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KNSObPolnG5GRdoj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::KNSObPolnG5GRdoj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0wZfIHUfkNoOnuj7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/expire',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@expire',
        'controller' => 'App\\Http\\Controllers\\AuthController@expire',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::0wZfIHUfkNoOnuj7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a7q1VwSv3XM5dAyJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@restore',
        'controller' => 'App\\Http\\Controllers\\AuthController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::a7q1VwSv3XM5dAyJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5Cl1a3SaXyITDLUz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@new_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@new_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::5Cl1a3SaXyITDLUz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4OP0BpZAsr6x7FcQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/activate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@use_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@use_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::4OP0BpZAsr6x7FcQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qMjP2ZR6ijI0lmYa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::qMjP2ZR6ijI0lmYa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7f3KrGFtV5v3UDfo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::7f3KrGFtV5v3UDfo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tVn51eRE5uRrU9Pj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::tVn51eRE5uRrU9Pj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oHvFt6iNplUlzSRz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::oHvFt6iNplUlzSRz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e6z4wHJjBa566eT3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::e6z4wHJjBa566eT3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i7EhXmTCMjtirvXT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::i7EhXmTCMjtirvXT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nwj5jB5ptv7lJBbD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::nwj5jB5ptv7lJBbD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4CQW2kgweDgcF7W1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::4CQW2kgweDgcF7W1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jELTJYKSpMOPMlu9' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::jELTJYKSpMOPMlu9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hhra5OyNCo031Ck5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@general_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@general_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::hhra5OyNCo031Ck5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TyYHvAnDTXtFeapn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/deleted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'controller' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::TyYHvAnDTXtFeapn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FYpuj4wa78SLSK3F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/sales-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::FYpuj4wa78SLSK3F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qxJ7VGvcXDtZPDSI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/opex-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::qxJ7VGvcXDtZPDSI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6SxlVRcUeSnFyKPx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/report/debt-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::6SxlVRcUeSnFyKPx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hDr5EgyuVBjGBC5E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/cogs-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::hDr5EgyuVBjGBC5E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7FWFFyLYGqQqYKsX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/method-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::7FWFFyLYGqQqYKsX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f6MkGlHfMPW2RMSa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/profit-loss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'controller' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::f6MkGlHfMPW2RMSa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UN6VtbU3sYxZ5CPq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::UN6VtbU3sYxZ5CPq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6ahCPM1gZhrdOwkO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::6ahCPM1gZhrdOwkO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nbxkkVHRRle4Gcdr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::nbxkkVHRRle4Gcdr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::08OsEaWwnO0k3cKd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/generate-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'controller' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::08OsEaWwnO0k3cKd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Lwv8y2KzqJr67Dta' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/transaction-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Lwv8y2KzqJr67Dta',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rJcKfCdjF0vzFMXG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user-sales-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::rJcKfCdjF0vzFMXG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a3izEWSACt14PXsn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007c30000000000000000";}";s:4:"hash";s:44:"PtrimX8dNamBkyDqoRPCzC1l2/Jdw/rp8WcZa6Xbz1Q=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a3izEWSACt14PXsn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
