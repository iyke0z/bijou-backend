<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a2JjLYdMuLlXkMjH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0onaaXtblWs4Kqqc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sx7Xjg4dxSAeaXjB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hiYnqGwhpLL2ZahY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/create-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ILRdAaRgNzyDwY3a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/delete-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IQhywBQkflqs0IZs',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::etdnbd4sbesckZK4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::POPgLaO2nobQohyT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z6K4gVXiShJkqwiE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/pay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Te4vSAnKSLrgStnE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R0cpA2x2d5KhaCXv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/food-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hrf9xWCc5i5qTpUY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/drink-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jRwJrh2BRBz639rk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/update-prep-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZNOjxmcrgEubYCRA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8OaOYEwsTKs64Uhz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vjAoDbG1LJu2r98F',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gu7frycdwLxKQKBL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/get-expiration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::umGF7wesL51cpJMf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V9xnb49NYgfL0YpS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eg6zStzJqIJFzHUv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Deb7sL3V7NfkPEmo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cg44hSmhwEemXnCt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PylE9vG4NUlxFuv8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ksgiUBSlwQl7MlSI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZUJ9UcssumsCxjuf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ekxuEP51UWT3FSmV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/role/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YUAYZ4R1DLqMT64F',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledge/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::anXoNZvJH66mEjHa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vzzhTAfG2dIQqBOX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::80vLSFua0fbjPPvX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LkqZNVOqcuyCFatt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/upload/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wtwsEC8Vx0sH4960',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TUJWlH1AD2o8fnvJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jffAiOiSiDsRzkkl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6avUZplqQWlE7k67',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zmIGdfAH90pxcOuh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LCg6yjTuk4EzrEVF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TdClUvf8XkawnVrK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/available' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Gfc6OYcyIgwD6zSa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YdQBEreA0ZYT4z8y',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/periodic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mJWmnUXPjKUDVvKt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/today' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QMLiT2176kRWTvgk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/pod' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wNIlIftPySY1FKtq',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/poc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::endKymtHJBe7p54g',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/expire' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e1C2kv2oYgPE2fTl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yjW0EgX5tmHKa9R4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::he3LXe2DIatFMBM2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/activate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oei0l2eT9AkPwlej',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uEtJqKmdkkXE9SJB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ttng0skguj0d4nPi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sWzEeQ6Rmf2uBZm1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yUYuAQjxEP6FTCri',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hwXUWYGzy9pUg29Z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oJSx2Tg0wrHNLF2C',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/deleted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NKkXIcq1sZ9LoPpT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/sales-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WOFHnH1FGAdFsEOL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/opex-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0UztnBZPfX1WRzsL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/debt-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SIasPyD8Ptz1foSn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/cogs-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rxeQFonPD8KuBe7H',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/method-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nfMd3SOBhdV19EmJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/profit-loss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6VPC7Drw0UECIJcK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gMD1ihcjvVDkLR3G',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g3QZrrLqH2fnXWgd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::texm2lgQJ5mQiaDP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/generate-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QZ1eTKIqsa7zdyYh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/transaction-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A6Eipr21B9tlxW4f',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user-sales-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dC5q1KkdBTG3NsWx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::68BBlIvnPeLhG6h7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/v1/(?|a(?|dmin/update\\-package/([^/]++)(*:51)|ssign/role/([^/]++)(*:77))|user(?|/(?|([^/]++)(*:104)|update/([^/]++)(*:127)|assign/([^/]++)(*:150)|delete/([^/]++)(*:173))|\\-transaction\\-report/([^/]++)(*:212))|role/delete/([^/]++)(*:241)|p(?|r(?|iviledge/delete/([^/]++)(*:281)|oduct/(?|update/([^/]++)(*:313)|delete/([^/]++)(*:336)|report/(?|([^/]++)(*:362)|all/([^/]++)(*:382))))|urchase/(?|update/([^/]++)(*:419)|de(?|tail/delete/([^/]++)(*:452)|lete/([^/]++)(*:473))))|c(?|ategory/(?|update/([^/]++)(*:514)|delete/([^/]++)(*:537))|ustomer/(?|update/([^/]++)(*:572)|fund/([^/]++)(*:593)|de(?|lete/([^/]++)(*:619)|tails/([^/]++)(*:641))))|discount/(?|update/([^/]++)(*:679)|delete/([^/]++)(*:702)|customer/(?|([^/]++)(*:730)|delete/([^/]++)/([^/]++)(*:762)))|business/(?|update/([^/]++)(*:799)|delete/([^/]++)(*:822))|expenditure/(?|type/(?|update/([^/]++)(*:869)|delete/([^/]++)(*:892))|update/([^/]++)(*:916)|delete/([^/]++)(*:939))))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bF9OcgM2dyAgh4pE',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      77 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vHU95wwCzqpAEUiH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1m9BodIVYUDXXBoJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fjfl2r2RHewpphxa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tnInu0NxF4g92GH8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AnsyJkJi3sq16SO6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      212 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::S9UjynkgMhmNobek',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      241 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qoIDhI6yhdcuwKnC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      281 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2zPRSbVfjUV0oAc5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      313 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZPGFU3De43NGM5i1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      336 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ziWbnfw3wDzshDFv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      362 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z2cB2bcNmU48vlbG',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      382 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hldV6yoWt7kNZJiF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      419 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f2I2KXD1rTBVTQqh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      452 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sJW8f4zJsz0Hveo1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      473 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VRBdg5hQJ9fe3nOv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      514 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5NIEFQnVOV9WALrC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      537 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OVOuzEam1D3w2dvQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::slLrRAhkFudjlw04',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      593 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DHjzK56l86Qj90c5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      619 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VeebTm4i0gygeKWc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rMTTVTVsp4KATlxZ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      679 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eCfWsQvGh6JGyaAd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      702 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RLJDenZn04NcmbVI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      730 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O7cYqexVmd0OcwWu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      762 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kPwPUwPE3QrhU0B5',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'discount',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      799 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NIhmxbPSDrUhBvhW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      822 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f6yhuyk0vY4uzGJy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      869 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TqKTeXU43SvWmltg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      892 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bqwmp2l1DVNcTHFO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      916 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PSIszJRNnfvBQAdW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      939 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::00l8N4UieIcUe6Kj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::a2JjLYdMuLlXkMjH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::a2JjLYdMuLlXkMjH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0onaaXtblWs4Kqqc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007c10000000000000000";}";s:4:"hash";s:44:"olGnWUbIuVrUJdF68bmTJEdZcEJYpdwopwP0jHt5vF8=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::0onaaXtblWs4Kqqc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sx7Xjg4dxSAeaXjB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'controller' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Sx7Xjg4dxSAeaXjB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hiYnqGwhpLL2ZahY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::hiYnqGwhpLL2ZahY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ILRdAaRgNzyDwY3a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/create-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::ILRdAaRgNzyDwY3a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bF9OcgM2dyAgh4pE' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/update-package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::bF9OcgM2dyAgh4pE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IQhywBQkflqs0IZs' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/delete-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::IQhywBQkflqs0IZs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::etdnbd4sbesckZK4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sell',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sell',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::etdnbd4sbesckZK4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::POPgLaO2nobQohyT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::POPgLaO2nobQohyT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z6K4gVXiShJkqwiE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'controller' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::z6K4gVXiShJkqwiE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Te4vSAnKSLrgStnE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@pay',
        'controller' => 'App\\Http\\Controllers\\TransactionController@pay',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Te4vSAnKSLrgStnE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R0cpA2x2d5KhaCXv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::R0cpA2x2d5KhaCXv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hrf9xWCc5i5qTpUY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/food-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::hrf9xWCc5i5qTpUY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jRwJrh2BRBz639rk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/drink-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::jRwJrh2BRBz639rk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZNOjxmcrgEubYCRA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/update-prep-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZNOjxmcrgEubYCRA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8OaOYEwsTKs64Uhz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_products',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_products',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::8OaOYEwsTKs64Uhz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vjAoDbG1LJu2r98F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'controller' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vjAoDbG1LJu2r98F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gu7frycdwLxKQKBL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/banks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'controller' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::gu7frycdwLxKQKBL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::umGF7wesL51cpJMf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/get-expiration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'controller' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::umGF7wesL51cpJMf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V9xnb49NYgfL0YpS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/business/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@show_business',
        'controller' => 'App\\Http\\Controllers\\AuthController@show_business',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::V9xnb49NYgfL0YpS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eg6zStzJqIJFzHUv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::eg6zStzJqIJFzHUv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Deb7sL3V7NfkPEmo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:606:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:387:"function (\\Illuminate\\Http\\Request $request) {
            $user = \\App\\Models\\User::with(\'role\')
            // ->with(\'purchase\')
            // ->with(\'sales\')
            ->with(\'access_log\')
            ->with(\'access_code\')
            // ->with(\'expenditure_types\')
            // ->with(\'expenditure\')
            ->find($request->user()->id);
            return $user;
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007da0000000000000000";}";s:4:"hash";s:44:"bpM3E24wloAVln0AhTMlclIhFI4GrFODfOOCwEE1uK0=";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Deb7sL3V7NfkPEmo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cg44hSmhwEemXnCt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::cg44hSmhwEemXnCt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PylE9vG4NUlxFuv8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_user',
        'controller' => 'App\\Http\\Controllers\\UserController@create_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::PylE9vG4NUlxFuv8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1m9BodIVYUDXXBoJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@get_user',
        'controller' => 'App\\Http\\Controllers\\UserController@get_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::1m9BodIVYUDXXBoJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Fjfl2r2RHewpphxa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update_user',
        'controller' => 'App\\Http\\Controllers\\UserController@update_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::Fjfl2r2RHewpphxa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tnInu0NxF4g92GH8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/assign/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::tnInu0NxF4g92GH8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AnsyJkJi3sq16SO6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_user',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::AnsyJkJi3sq16SO6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ksgiUBSlwQl7MlSI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_users',
        'controller' => 'App\\Http\\Controllers\\UserController@all_users',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::ksgiUBSlwQl7MlSI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZUJ9UcssumsCxjuf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_roles',
        'controller' => 'App\\Http\\Controllers\\UserController@all_roles',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZUJ9UcssumsCxjuf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ekxuEP51UWT3FSmV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/priviledges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'controller' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ekxuEP51UWT3FSmV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YUAYZ4R1DLqMT64F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_role',
        'controller' => 'App\\Http\\Controllers\\UserController@create_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::YUAYZ4R1DLqMT64F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qoIDhI6yhdcuwKnC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_role',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::qoIDhI6yhdcuwKnC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::anXoNZvJH66mEjHa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::anXoNZvJH66mEjHa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2zPRSbVfjUV0oAc5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::2zPRSbVfjUV0oAc5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vHU95wwCzqpAEUiH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/assign/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vHU95wwCzqpAEUiH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vzzhTAfG2dIQqBOX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::vzzhTAfG2dIQqBOX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5NIEFQnVOV9WALrC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::5NIEFQnVOV9WALrC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OVOuzEam1D3w2dvQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::OVOuzEam1D3w2dvQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::80vLSFua0fbjPPvX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::80vLSFua0fbjPPvX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LkqZNVOqcuyCFatt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::LkqZNVOqcuyCFatt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZPGFU3De43NGM5i1' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/product/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::ZPGFU3De43NGM5i1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ziWbnfw3wDzshDFv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::ziWbnfw3wDzshDFv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z2cB2bcNmU48vlbG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::z2cB2bcNmU48vlbG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hldV6yoWt7kNZJiF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::hldV6yoWt7kNZJiF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wtwsEC8Vx0sH4960' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/upload/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'controller' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::wtwsEC8Vx0sH4960',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TUJWlH1AD2o8fnvJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::TUJWlH1AD2o8fnvJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f2I2KXD1rTBVTQqh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::f2I2KXD1rTBVTQqh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sJW8f4zJsz0Hveo1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/detail/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::sJW8f4zJsz0Hveo1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VRBdg5hQJ9fe3nOv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::VRBdg5hQJ9fe3nOv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jffAiOiSiDsRzkkl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::jffAiOiSiDsRzkkl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6avUZplqQWlE7k67' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::6avUZplqQWlE7k67',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zmIGdfAH90pxcOuh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::zmIGdfAH90pxcOuh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::slLrRAhkFudjlw04' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::slLrRAhkFudjlw04',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DHjzK56l86Qj90c5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/fund/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::DHjzK56l86Qj90c5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VeebTm4i0gygeKWc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::VeebTm4i0gygeKWc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rMTTVTVsp4KATlxZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'controller' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::rMTTVTVsp4KATlxZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LCg6yjTuk4EzrEVF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::LCg6yjTuk4EzrEVF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eCfWsQvGh6JGyaAd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::eCfWsQvGh6JGyaAd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RLJDenZn04NcmbVI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::RLJDenZn04NcmbVI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O7cYqexVmd0OcwWu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::O7cYqexVmd0OcwWu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TdClUvf8XkawnVrK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::TdClUvf8XkawnVrK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Gfc6OYcyIgwD6zSa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount/available',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::Gfc6OYcyIgwD6zSa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kPwPUwPE3QrhU0B5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/delete/{id}/{discount}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::kPwPUwPE3QrhU0B5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YdQBEreA0ZYT4z8y' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/sell/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::YdQBEreA0ZYT4z8y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mJWmnUXPjKUDVvKt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/periodic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::mJWmnUXPjKUDVvKt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QMLiT2176kRWTvgk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/today',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::QMLiT2176kRWTvgk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wNIlIftPySY1FKtq' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/pod',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::wNIlIftPySY1FKtq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::endKymtHJBe7p54g' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/poc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::endKymtHJBe7p54g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NIhmxbPSDrUhBvhW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::NIhmxbPSDrUhBvhW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f6yhuyk0vY4uzGJy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::f6yhuyk0vY4uzGJy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e1C2kv2oYgPE2fTl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/expire',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@expire',
        'controller' => 'App\\Http\\Controllers\\AuthController@expire',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::e1C2kv2oYgPE2fTl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yjW0EgX5tmHKa9R4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@restore',
        'controller' => 'App\\Http\\Controllers\\AuthController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::yjW0EgX5tmHKa9R4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::he3LXe2DIatFMBM2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@new_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@new_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::he3LXe2DIatFMBM2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oei0l2eT9AkPwlej' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/activate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@use_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@use_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::oei0l2eT9AkPwlej',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uEtJqKmdkkXE9SJB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::uEtJqKmdkkXE9SJB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TqKTeXU43SvWmltg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::TqKTeXU43SvWmltg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bqwmp2l1DVNcTHFO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::Bqwmp2l1DVNcTHFO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ttng0skguj0d4nPi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::Ttng0skguj0d4nPi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sWzEeQ6Rmf2uBZm1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::sWzEeQ6Rmf2uBZm1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PSIszJRNnfvBQAdW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::PSIszJRNnfvBQAdW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::00l8N4UieIcUe6Kj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::00l8N4UieIcUe6Kj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yUYuAQjxEP6FTCri' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::yUYuAQjxEP6FTCri',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hwXUWYGzy9pUg29Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::hwXUWYGzy9pUg29Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oJSx2Tg0wrHNLF2C' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@general_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@general_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::oJSx2Tg0wrHNLF2C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NKkXIcq1sZ9LoPpT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/deleted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'controller' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::NKkXIcq1sZ9LoPpT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WOFHnH1FGAdFsEOL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/sales-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::WOFHnH1FGAdFsEOL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0UztnBZPfX1WRzsL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/opex-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::0UztnBZPfX1WRzsL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SIasPyD8Ptz1foSn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/report/debt-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::SIasPyD8Ptz1foSn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rxeQFonPD8KuBe7H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/cogs-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::rxeQFonPD8KuBe7H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nfMd3SOBhdV19EmJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/method-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::nfMd3SOBhdV19EmJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6VPC7Drw0UECIJcK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/profit-loss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'controller' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::6VPC7Drw0UECIJcK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gMD1ihcjvVDkLR3G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::gMD1ihcjvVDkLR3G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g3QZrrLqH2fnXWgd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::g3QZrrLqH2fnXWgd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::texm2lgQJ5mQiaDP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::texm2lgQJ5mQiaDP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QZ1eTKIqsa7zdyYh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/generate-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'controller' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::QZ1eTKIqsa7zdyYh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A6Eipr21B9tlxW4f' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/transaction-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::A6Eipr21B9tlxW4f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::S9UjynkgMhmNobek' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user-transaction-report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_user_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_user_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::S9UjynkgMhmNobek',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dC5q1KkdBTG3NsWx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user-sales-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::dC5q1KkdBTG3NsWx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::68BBlIvnPeLhG6h7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007c40000000000000000";}";s:4:"hash";s:44:"Qkw0PevMBP4tZjjx8GHbkG9/vw5tVM4wTkImIBFKWe4=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::68BBlIvnPeLhG6h7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
