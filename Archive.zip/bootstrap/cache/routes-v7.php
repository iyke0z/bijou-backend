<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZpVM0cIS6kqJ5HZY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YFz3gnmS4sLN1Mdm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WI1GtBTJZboOdHCl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::n2TUlqkuPW6TPQuX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/create-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s2zfnYmIhky9YOtv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/delete-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::icE8HYe9b0SkqPtK',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GJRYq1YdKu9HAaYu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xRR16TgCwakLFgRl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N11Izj95hHlIu7Te',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/pay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9c9XoankYjJUnxsK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fF2dGQgkNMAg2YRf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/food-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ew07DraPTsDpOlf3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/drink-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZRQElwii4fMmEDXE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/update-prep-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sAFGAGzz11CMzMnn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J9Ipmj5cmWAWwlKV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4GHApVrOZfGOurpy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D8PvyrybaSAipFEA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/get-expiration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2uCCS9oy0JlbQrPy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MoonVxr7PsQ0INlz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xARBIJ50Ng95en3e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EzlF2kgyu91dGCKA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vM94DqkQW7dQi8Va',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Fi0Vx5O9g7B8pyHu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p6jaLfiGbjl7MnWn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dNARQxJsZS8oijCD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kEz2a1QbVXlvkGrw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/role/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ice7LaNnYCiiNoYu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledge/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PUXOyf1yPIbsYkGw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B2RLRasta4Z4WYE6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bA3uRl5iR0NNMjX7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zdBEmLBd1dj7z3Ux',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/upload/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GGw20A9NBkxgTdxO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pMjF7u0OBMQRWZSl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qx8WzRfz1KWYoa9H',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AOhqJtVqDvo9BxlF',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ygJhpMEKw0SNX6tB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ErsKZ8MjI7zYFVoQ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CFxK6WGQIUJ8MpHt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/available' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Hu6ANmhxD1iagIq3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HLV5TSqMeEnKxV7u',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/periodic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SWeOaIhe422jkmI0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/today' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kam7wtrMWIMe69nL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/pod' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ga88vnS4lsKc1jxP',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/poc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gcNIWmkbxNURdHNn',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/expire' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zGwvvfej2RvDglLd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BWy3MnaI4CeoAgJz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bXx5Uq3DbMdhLn98',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/activate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VEoL9rbjqnrqP5K5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NMdYpGFaacRvXyp8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lwcvnoKnJ0Ub7tbx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wpd4OGNwDGogL1Q4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::m0jxiKO76XAC8MFz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ew7voyMkVHYfl0f0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q5h6VnZO5F4nBrg3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/deleted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mOJIzZSVyVYYwhbz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/sales-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oR5nuaIFi1RUxD7i',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/opex-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7M2uiMmGPFyIkmLg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/debt-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AbiMjll4YJWuIIgB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/cogs-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T9FbdCiiYLPLAt6m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/method-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6IsBkj5bGKFwNX3U',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/profit-loss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fSMhD6OyKwWJdIaO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qt6dOGBbxQZuRf3O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oPzF41XnLjrgkJOK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tPKgyze380Xzs0Dy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/generate-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QQChvdqOYvcXuNfJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/transaction-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::asoBdP3b9LpgNW4e',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user-sales-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JnSYmpGTthGAD4CH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CZB9HHZ7D4u2fYc6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/v1/(?|a(?|dmin/update\\-package/([^/]++)(*:51)|ssign/role/([^/]++)(*:77))|user/(?|([^/]++)(*:101)|update/([^/]++)(*:124)|assign/([^/]++)(*:147)|delete/([^/]++)(*:170))|role/delete/([^/]++)(*:199)|p(?|r(?|iviledge/delete/([^/]++)(*:239)|oduct/(?|update/([^/]++)(*:271)|delete/([^/]++)(*:294)|report/(?|([^/]++)(*:320)|all/([^/]++)(*:340))))|urchase/(?|update/([^/]++)(*:377)|de(?|tail/delete/([^/]++)(*:410)|lete/([^/]++)(*:431))))|c(?|ategory/(?|update/([^/]++)(*:472)|delete/([^/]++)(*:495))|ustomer/(?|update/([^/]++)(*:530)|fund/([^/]++)(*:551)|de(?|lete/([^/]++)(*:577)|tails/([^/]++)(*:599))))|discount/(?|update/([^/]++)(*:637)|delete/([^/]++)(*:660)|customer/(?|([^/]++)(*:688)|delete/([^/]++)/([^/]++)(*:720)))|business/(?|update/([^/]++)(*:757)|delete/([^/]++)(*:780))|expenditure/(?|type/(?|update/([^/]++)(*:827)|delete/([^/]++)(*:850))|update/([^/]++)(*:874)|delete/([^/]++)(*:897))))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gTLsWje7p2UWiRfi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      77 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9Rb5mvogaIHdlm8l',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      101 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::02ODBoHsSuoQsf2x',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      124 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GnvOwyooBOKjf0Xz',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      147 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::piHBtqa5uswqLHG4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EUfzxtv8Vux4AVAm',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      199 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7QwZnEvDVPfD2RTx',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      239 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LVQeqOVIvFJGXK9p',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      271 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GksLkOkAqzo7Tya5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      294 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sXVKhgctIjCZtO88',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      320 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WkTaG8QUWVAn1NsB',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jyfy2FxmGz71TRaY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      377 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wZhsEcUoUc3A0vKA',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FEBQBIPPrf5tAbbi',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      431 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a1cYm5OtNCDeS10P',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      472 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GlF8rIdWW1EB70ng',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      495 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::geR7Jc14XQDREqSv',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      530 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k2EpJRAiW6ztHT8Y',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      551 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9707oR7Iksxhj8Oh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::THOIFZ6OrQNpWWuY',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      599 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w2JHiyHTQmSt4SEa',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rp9WzoOgfrPnRGze',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CKg86FGuQDLZciFj',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      688 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ErbZwZ3C5hCOEP7T',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      720 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tS42R8QVKxmEhVlD',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'discount',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      757 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bXJOh9JVSN0ht5cC',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      780 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fJZ2eSTJVt2QhJfN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      827 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gISk8Gb6ucKlm5N5',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      850 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bbf71FClfW7k7b5G',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      874 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jD0LHDZekZv62s2Z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      897 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RDdTcAcvUHp65unc',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::ZpVM0cIS6kqJ5HZY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::ZpVM0cIS6kqJ5HZY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YFz3gnmS4sLN1Mdm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007c00000000000000000";}";s:4:"hash";s:44:"LAzIQ4V+KGG/8Sp8T8c2+1oQJlPsxSETe1WPZp6cieQ=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::YFz3gnmS4sLN1Mdm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WI1GtBTJZboOdHCl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'controller' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::WI1GtBTJZboOdHCl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::n2TUlqkuPW6TPQuX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::n2TUlqkuPW6TPQuX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s2zfnYmIhky9YOtv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/create-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::s2zfnYmIhky9YOtv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gTLsWje7p2UWiRfi' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/update-package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::gTLsWje7p2UWiRfi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::icE8HYe9b0SkqPtK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/delete-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::icE8HYe9b0SkqPtK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GJRYq1YdKu9HAaYu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sell',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sell',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::GJRYq1YdKu9HAaYu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xRR16TgCwakLFgRl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::xRR16TgCwakLFgRl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N11Izj95hHlIu7Te' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'controller' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::N11Izj95hHlIu7Te',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9c9XoankYjJUnxsK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@pay',
        'controller' => 'App\\Http\\Controllers\\TransactionController@pay',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::9c9XoankYjJUnxsK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fF2dGQgkNMAg2YRf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::fF2dGQgkNMAg2YRf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ew07DraPTsDpOlf3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/food-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ew07DraPTsDpOlf3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZRQElwii4fMmEDXE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/drink-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZRQElwii4fMmEDXE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sAFGAGzz11CMzMnn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/update-prep-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::sAFGAGzz11CMzMnn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J9Ipmj5cmWAWwlKV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_products',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_products',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::J9Ipmj5cmWAWwlKV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4GHApVrOZfGOurpy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'controller' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::4GHApVrOZfGOurpy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D8PvyrybaSAipFEA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/banks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'controller' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::D8PvyrybaSAipFEA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2uCCS9oy0JlbQrPy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/get-expiration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'controller' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::2uCCS9oy0JlbQrPy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MoonVxr7PsQ0INlz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/business/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@show_business',
        'controller' => 'App\\Http\\Controllers\\AuthController@show_business',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::MoonVxr7PsQ0INlz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xARBIJ50Ng95en3e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::xARBIJ50Ng95en3e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EzlF2kgyu91dGCKA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:606:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:387:"function (\\Illuminate\\Http\\Request $request) {
            $user = \\App\\Models\\User::with(\'role\')
            // ->with(\'purchase\')
            // ->with(\'sales\')
            ->with(\'access_log\')
            ->with(\'access_code\')
            // ->with(\'expenditure_types\')
            // ->with(\'expenditure\')
            ->find($request->user()->id);
            return $user;
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007d90000000000000000";}";s:4:"hash";s:44:"9vq/Ezpxj9d75Xk+jklnMmzsu62jEN811by2paK0T9M=";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::EzlF2kgyu91dGCKA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vM94DqkQW7dQi8Va' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vM94DqkQW7dQi8Va',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Fi0Vx5O9g7B8pyHu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_user',
        'controller' => 'App\\Http\\Controllers\\UserController@create_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::Fi0Vx5O9g7B8pyHu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::02ODBoHsSuoQsf2x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@get_user',
        'controller' => 'App\\Http\\Controllers\\UserController@get_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::02ODBoHsSuoQsf2x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GnvOwyooBOKjf0Xz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update_user',
        'controller' => 'App\\Http\\Controllers\\UserController@update_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::GnvOwyooBOKjf0Xz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::piHBtqa5uswqLHG4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/assign/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::piHBtqa5uswqLHG4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EUfzxtv8Vux4AVAm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_user',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::EUfzxtv8Vux4AVAm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p6jaLfiGbjl7MnWn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_users',
        'controller' => 'App\\Http\\Controllers\\UserController@all_users',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::p6jaLfiGbjl7MnWn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dNARQxJsZS8oijCD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_roles',
        'controller' => 'App\\Http\\Controllers\\UserController@all_roles',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::dNARQxJsZS8oijCD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kEz2a1QbVXlvkGrw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/priviledges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'controller' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::kEz2a1QbVXlvkGrw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ice7LaNnYCiiNoYu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_role',
        'controller' => 'App\\Http\\Controllers\\UserController@create_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Ice7LaNnYCiiNoYu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7QwZnEvDVPfD2RTx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_role',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::7QwZnEvDVPfD2RTx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PUXOyf1yPIbsYkGw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::PUXOyf1yPIbsYkGw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LVQeqOVIvFJGXK9p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::LVQeqOVIvFJGXK9p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9Rb5mvogaIHdlm8l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/assign/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::9Rb5mvogaIHdlm8l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B2RLRasta4Z4WYE6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::B2RLRasta4Z4WYE6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GlF8rIdWW1EB70ng' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::GlF8rIdWW1EB70ng',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::geR7Jc14XQDREqSv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::geR7Jc14XQDREqSv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bA3uRl5iR0NNMjX7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::bA3uRl5iR0NNMjX7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zdBEmLBd1dj7z3Ux' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::zdBEmLBd1dj7z3Ux',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GksLkOkAqzo7Tya5' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/product/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::GksLkOkAqzo7Tya5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sXVKhgctIjCZtO88' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::sXVKhgctIjCZtO88',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WkTaG8QUWVAn1NsB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::WkTaG8QUWVAn1NsB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jyfy2FxmGz71TRaY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::Jyfy2FxmGz71TRaY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GGw20A9NBkxgTdxO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/upload/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'controller' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::GGw20A9NBkxgTdxO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pMjF7u0OBMQRWZSl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::pMjF7u0OBMQRWZSl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wZhsEcUoUc3A0vKA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::wZhsEcUoUc3A0vKA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FEBQBIPPrf5tAbbi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/detail/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::FEBQBIPPrf5tAbbi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a1cYm5OtNCDeS10P' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::a1cYm5OtNCDeS10P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qx8WzRfz1KWYoa9H' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::qx8WzRfz1KWYoa9H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AOhqJtVqDvo9BxlF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::AOhqJtVqDvo9BxlF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ygJhpMEKw0SNX6tB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::ygJhpMEKw0SNX6tB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k2EpJRAiW6ztHT8Y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::k2EpJRAiW6ztHT8Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9707oR7Iksxhj8Oh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/fund/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::9707oR7Iksxhj8Oh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::THOIFZ6OrQNpWWuY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::THOIFZ6OrQNpWWuY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w2JHiyHTQmSt4SEa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'controller' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::w2JHiyHTQmSt4SEa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ErsKZ8MjI7zYFVoQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::ErsKZ8MjI7zYFVoQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rp9WzoOgfrPnRGze' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::Rp9WzoOgfrPnRGze',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CKg86FGuQDLZciFj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::CKg86FGuQDLZciFj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ErbZwZ3C5hCOEP7T' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::ErbZwZ3C5hCOEP7T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CFxK6WGQIUJ8MpHt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::CFxK6WGQIUJ8MpHt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Hu6ANmhxD1iagIq3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount/available',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::Hu6ANmhxD1iagIq3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tS42R8QVKxmEhVlD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/delete/{id}/{discount}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::tS42R8QVKxmEhVlD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HLV5TSqMeEnKxV7u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/sell/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::HLV5TSqMeEnKxV7u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SWeOaIhe422jkmI0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/periodic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::SWeOaIhe422jkmI0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Kam7wtrMWIMe69nL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/today',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::Kam7wtrMWIMe69nL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ga88vnS4lsKc1jxP' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/pod',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::Ga88vnS4lsKc1jxP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gcNIWmkbxNURdHNn' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/poc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::gcNIWmkbxNURdHNn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bXJOh9JVSN0ht5cC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::bXJOh9JVSN0ht5cC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fJZ2eSTJVt2QhJfN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::fJZ2eSTJVt2QhJfN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zGwvvfej2RvDglLd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/expire',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@expire',
        'controller' => 'App\\Http\\Controllers\\AuthController@expire',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::zGwvvfej2RvDglLd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BWy3MnaI4CeoAgJz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@restore',
        'controller' => 'App\\Http\\Controllers\\AuthController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::BWy3MnaI4CeoAgJz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bXx5Uq3DbMdhLn98' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@new_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@new_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::bXx5Uq3DbMdhLn98',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VEoL9rbjqnrqP5K5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/activate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@use_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@use_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::VEoL9rbjqnrqP5K5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NMdYpGFaacRvXyp8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::NMdYpGFaacRvXyp8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gISk8Gb6ucKlm5N5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::gISk8Gb6ucKlm5N5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bbf71FClfW7k7b5G' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::bbf71FClfW7k7b5G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lwcvnoKnJ0Ub7tbx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::lwcvnoKnJ0Ub7tbx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wpd4OGNwDGogL1Q4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::wpd4OGNwDGogL1Q4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jD0LHDZekZv62s2Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::jD0LHDZekZv62s2Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RDdTcAcvUHp65unc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::RDdTcAcvUHp65unc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::m0jxiKO76XAC8MFz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::m0jxiKO76XAC8MFz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ew7voyMkVHYfl0f0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::Ew7voyMkVHYfl0f0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q5h6VnZO5F4nBrg3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@general_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@general_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::Q5h6VnZO5F4nBrg3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mOJIzZSVyVYYwhbz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/deleted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'controller' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::mOJIzZSVyVYYwhbz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oR5nuaIFi1RUxD7i' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/sales-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::oR5nuaIFi1RUxD7i',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7M2uiMmGPFyIkmLg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/opex-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::7M2uiMmGPFyIkmLg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AbiMjll4YJWuIIgB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/report/debt-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::AbiMjll4YJWuIIgB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T9FbdCiiYLPLAt6m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/cogs-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::T9FbdCiiYLPLAt6m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6IsBkj5bGKFwNX3U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/method-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::6IsBkj5bGKFwNX3U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fSMhD6OyKwWJdIaO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/profit-loss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'controller' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::fSMhD6OyKwWJdIaO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qt6dOGBbxQZuRf3O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::qt6dOGBbxQZuRf3O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oPzF41XnLjrgkJOK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::oPzF41XnLjrgkJOK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tPKgyze380Xzs0Dy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::tPKgyze380Xzs0Dy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QQChvdqOYvcXuNfJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/generate-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'controller' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::QQChvdqOYvcXuNfJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::asoBdP3b9LpgNW4e' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/transaction-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::asoBdP3b9LpgNW4e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JnSYmpGTthGAD4CH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user-sales-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::JnSYmpGTthGAD4CH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CZB9HHZ7D4u2fYc6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:262:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:44:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000007c30000000000000000";}";s:4:"hash";s:44:"PtrimX8dNamBkyDqoRPCzC1l2/Jdw/rp8WcZa6Xbz1Q=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CZB9HHZ7D4u2fYc6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
