<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;
use App\Http\Controllers\AuthController as Auth;

class SalesTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_sale_for_customer_with_discount()
    {
        //
    }

    public function test_sale_for_customer_with_dicount_code()
    {
        //
    }

    public function test_sale_for_customer_no_dicount()
    {
        //
    }

    public function test_sale_for_guest_with_discount_code()
    {
        //
    }

    public function test_sale_for_guest_with_not_discount_code()
    {
        //
    }

}
