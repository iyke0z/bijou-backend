<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LogisticAccountController extends Controller
{
    public function debitTransaction(){
        
    }
}
