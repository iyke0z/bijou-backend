<?php

namespace App\Interfaces;

interface ReportRepositoryInterface{
    public function downloadReport($request);
}
