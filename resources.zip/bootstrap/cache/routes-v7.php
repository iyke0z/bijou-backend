<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gmZj13ewbHlz8TOf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BEcMKy1rb6QduH5q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::03Jat2qFfputSqA6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/sales-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pl2BnzKVCGmxLqMc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/details' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::19n5oJ9ygcHxVDEe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user-count' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rgOkUSkRbZydg8GQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::X5THZbJ7aUPLNmGc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/create-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eRjt6QAJwFXnjH2h',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/delete-package' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WnTmnmYVJwd1TKQM',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/business/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::f661Lo0FaaNt3oZm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/admin/create/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lTtuKOxfHSOqZerr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_transactions',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QQBRnRQruQfsRmtX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vd7GY3WmG7se8y4r',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/pay' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tzp9BPXDHpbSXFXM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hjHmoikecioe6U2L',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/food-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dYe7cXEgIxuBWGxP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/drink-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7gl86ceYBQyBBOn8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/update-prep-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pcY0Eu56biVpbIfk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DupRhI3QHAi83Ewv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/get-expiration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U2ScsBEMYz3MYLL6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RjYCvjzimKulKbQU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5zqpFY17dbFC3j0G',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CylWEP5ndbqjku1S',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7NE127WdiYBvUYHq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cP9i9b8ATh4DUH68',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_user',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XigrDj8ffbtUklzu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::F8WeCkoFIvXCEuG8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sLT8AkPIPlsHitoi',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/role/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_roles',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/priviledge/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y1CmQOytAsHsLzll',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_categories',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/category' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ScXpCE7gNdsdHA3t',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_products',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/product/upload/image' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zxpIas6r7aobHhQU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iVTmqYCXLShtwu9E',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CBfhfBFdLULaPPeC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xafjPym2VL688wDy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/purchase/documents/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fXF35dFQTYiuFefZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/customer/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_customers',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9JoJ6tVGRyZeFKYK',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7NCasSxsXgTMNPip',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/discount/available' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HFYfGHlL1ffdSFps',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ok6wkAs2H7g9vSN9',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/periodic' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C8swdkYocafwu4Hc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/today' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qyq8uvMXFMvw2J6w',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/pod' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qrQkKgmxtnidyiai',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/sell/verify/poc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ka7UsnDl35ugnZum',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/expire' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4uTBJPs5yVHkuYuC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/business/restore' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W1vhNTCLliAaaWzy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/new' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KCZRkl7N6CKKaHdx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/activation/activate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yEBpN88Cc2jcz5bW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vATf8yPgv8dFE6g0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/type' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vgrsmbvEf3CCk7wU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_expenditures',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rrjmRuUJ2PHiiG2b',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ElEHooqtiQizR7Fg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/expenditure/documents/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5tqxMt2SgY4SIKUH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/budget/create-budget' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YLgOBsiiwUDXd2Du',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/budget/show-budget' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LdM83hSeXBuv5DYQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DDtIzwuhA43xdno1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/deleted' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::njr4PIY0JmPDRuQy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/sales-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gB25as9kIdPLl3ma',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/opex-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i6HKTJzud2xju8Zr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/debt-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uBniWhdY9siiDrPu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/cogs-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VpKgmGNkX2Iuc7Ad',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/method-performance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pfciqAfJU72chQu5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/profit-loss' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MRco5Rk1PYgbeRI0',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/bank-balance' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hOgQYU4DXkl9p3cj',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/bank-statement' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vzd3V2PM1HXlM43E',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/logistics-statement' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FRTrnWuahm8OfEBy',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/payables' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E8WNsCJ2ce7KIjL4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/report/download' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gsg3NycheBPkGUBw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/backend/sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sales',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/backend/purchases' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'purchases',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/backend/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'products',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/backend/expenditure' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'expenditure',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/backend/staff' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'staff',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/backend/customer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'customer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/store' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sRcoFUGc4HK5xdkW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ctN5kKiNw3AXqGJX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/banks/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SrNKkd99vTIokElS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/generate-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZXw4hCmFLmvg4H4O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/transaction-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SV63nbCsDTkJae51',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/user-sales-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tQNckeO0esZc7saW',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/shop/all' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XVP35NMJwkBvYBhE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/shop/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'create_branches',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/shop/initiate-transfer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wCT3CANFlIsMisPh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/goods_delivery_notes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'goods_delivery_notes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'goods_delivery_notes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sheV9Eu0m3fjoKHw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/api/v1/(?|a(?|dmin/update\\-package/([^/]++)(*:51)|ssign/role/([^/]++)(*:77))|user(?|/(?|([^/]++)(*:104)|update/([^/]++)(*:127)|assign/([^/]++)(*:150)|delete/([^/]++)(*:173))|\\-transaction\\-report/([^/]++)(*:212))|role/(?|delete/([^/]++)(*:244)|priviledges/([^/]++)(*:272))|p(?|r(?|iviledge/delete/([^/]++)(*:313)|oduct/(?|update/([^/]++)(*:345)|delete/([^/]++)(*:368)|report/(?|([^/]++)(*:394)|all/([^/]++)(*:414))))|urchase/(?|update(?|/([^/]++)(*:454)|\\-plan/([^/]++)(*:477))|d(?|e(?|tail/delete/([^/]++)(*:514)|lete/([^/]++)(*:535))|ocuments/d(?|elete/([^/]++)(*:571)|ownload/([^/]++)(*:595)))))|c(?|ategory/(?|update/([^/]++)(*:637)|delete/([^/]++)(*:660))|ustomer/(?|update/([^/]++)(*:695)|fund/([^/]++)(*:716)|de(?|lete/([^/]++)(*:742)|tails/([^/]++)(*:764))))|discount/(?|update/([^/]++)(*:802)|delete/([^/]++)(*:825)|customer/(?|([^/]++)(*:853)|delete/([^/]++)/([^/]++)(*:885)))|s(?|ell/update/([^/]++)(*:918)|hop/(?|a(?|ssign/([^/]++)(*:951)|pprove\\-transfer/([^/]++)(*:984))|update/([^/]++)(*:1008)|one/([^/]++)(*:1029)|delete/([^/]++)(*:1053)|re(?|ject\\-transfer/([^/]++)(*:1090)|cent\\-transfers/([^/]++)(*:1123))))|bu(?|siness/(?|update/([^/]++)(*:1165)|delete/([^/]++)(*:1189))|dget/(?|delete\\-budget/([^/]++)(*:1230)|update\\-budget/([^/]++)(*:1262)))|expenditure/(?|type/(?|update/([^/]++)(*:1311)|delete/([^/]++)(*:1335))|update(?|/([^/]++)(*:1363)|\\-plan/([^/]++)(*:1387))|d(?|elete/([^/]++)(*:1415)|ocuments/d(?|elete/([^/]++)(*:1451)|ownload/([^/]++)(*:1476))))|goods_delivery_notes/([^/]++)(?|(*:1520)|/download(*:1538))))/?$}sDu',
    ),
    3 => 
    array (
      51 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Su8PeXXl1XaUCIwy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      77 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HYUwayctJcDNaxHM',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z65kn29uMv1lCAvf',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::g3WXVDPDQhZjxMnH',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      150 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RWJpHXxxCmhJUpmR',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      173 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::64dFvfKzgLXt9Ar3',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      212 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::W8pTwV7CKwn2SZ3W',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      244 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KBE8THlxKQoaCtXd',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      272 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y2eg0OifqhAMufxJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      313 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::riixGlyFKJZIkOuq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      345 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7RaHVw9nK85VIXFQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      368 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gnaL7NNjKrWxv53U',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qSNEydLO8ON3hxW1',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      414 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7D6U1PKKw8blFequ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      454 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uJkteB7nLrO4GB71',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      477 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eQevlxYzDszJJs8d',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      514 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GzncGj9BC8bdug5t',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      535 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BKSwRsaRNlPquyAp',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      571 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CRn2dJI31hxnAQst',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      595 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Uqb8uCyM1GSW58vD',
          ),
          1 => 
          array (
            0 => 'purchase_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NNSMSkdNfkgYnucQ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      660 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dh4kaHErEJnx3zFu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      695 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vw4Tnvl8JyrvXF2Z',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      716 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7wADa8PBw6iUVLGJ',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      742 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TafexCNeRxAHWXZx',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      764 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yLwNepxZf98LyGcI',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      802 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TLhPQbH7EXXbFFGW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      825 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tK9btZFpQK3QVwJN',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      853 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jibKs90bEO6ItmiV',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      885 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a27yb1rVK9m3x8lO',
          ),
          1 => 
          array (
            0 => 'id',
            1 => 'discount',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      918 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o1tpUsmvbel2csj0',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      951 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OieRHk8sBi6wPT8f',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      984 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::25KvgTd5NdyXTHUU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1008 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5ZJJfE9uSBnOrXYD',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1029 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SHY47bBGSoD8MUSu',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1053 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gEGD5dZmNoDfCB9x',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WDMfU29V55ZsEWjL',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1123 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HbVqD2g45vy8xgZh',
          ),
          1 => 
          array (
            0 => 'shopId',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1165 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z3QqdRv85ibqjEmU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1189 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DToI0TQtqdIyTVzg',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1230 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MqAn8EkiCNgP8zoO',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1262 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NGrTkJXwUtShIJSF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1311 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8Uzz6fbaNp72ec5B',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1335 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pWlRJzUVzt3VCRR4',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1363 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::D8Uj4QP3ApOULnjn',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1387 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::29IBU09359wE6o6f',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1415 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MM5HbHPGiFumx4DF',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1451 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M1Hf5K6TLUjvB9CK',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zHpTN9Eu4cHLcXiv',
          ),
          1 => 
          array (
            0 => 'purchase_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1520 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'goods_delivery_notes.show',
          ),
          1 => 
          array (
            0 => 'goodsDeliveryNote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'goods_delivery_notes.update',
          ),
          1 => 
          array (
            0 => 'goodsDeliveryNote',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1538 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'goods_delivery_notes.download',
          ),
          1 => 
          array (
            0 => 'goodsDeliveryNote',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::gmZj13ewbHlz8TOf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::gmZj13ewbHlz8TOf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BEcMKy1rb6QduH5q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:297:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:79:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008010000000000000000";}";s:4:"hash";s:44:"ZbZ026pLrY4C7be4dPVE4340Z/HwVJa6TKPfxEy26z4=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::BEcMKy1rb6QduH5q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::03Jat2qFfputSqA6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'controller' => 'App\\Http\\Controllers\\WebHookController@webHookHandler',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::03Jat2qFfputSqA6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pl2BnzKVCGmxLqMc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/sales-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::pl2BnzKVCGmxLqMc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::19n5oJ9ygcHxVDEe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/business/details',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@show_business',
        'controller' => 'App\\Http\\Controllers\\AuthController@show_business',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::19n5oJ9ygcHxVDEe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rgOkUSkRbZydg8GQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user-count',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@userCount',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@userCount',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::rgOkUSkRbZydg8GQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::X5THZbJ7aUPLNmGc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/admin/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@getPackages',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::X5THZbJ7aUPLNmGc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eRjt6QAJwFXnjH2h' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/create-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@createPackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::eRjt6QAJwFXnjH2h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Su8PeXXl1XaUCIwy' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/admin/update-package/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@updatePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::Su8PeXXl1XaUCIwy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WnTmnmYVJwd1TKQM' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/admin/delete-package',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'controller' => 'App\\Http\\Controllers\\SuperAdminController@deletePackage',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::WnTmnmYVJwd1TKQM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::f661Lo0FaaNt3oZm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/business/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::f661Lo0FaaNt3oZm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lTtuKOxfHSOqZerr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/admin/create/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_user',
        'controller' => 'App\\Http\\Controllers\\UserController@create_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/admin',
        'where' => 
        array (
        ),
        'as' => 'generated::lTtuKOxfHSOqZerr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_transactions' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
          2 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sell',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sell',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'create_transactions',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QQBRnRQruQfsRmtX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::QQBRnRQruQfsRmtX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vd7GY3WmG7se8y4r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'controller' => 'App\\Http\\Controllers\\TransactionController@get_active_orders',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vd7GY3WmG7se8y4r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tzp9BPXDHpbSXFXM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@pay',
        'controller' => 'App\\Http\\Controllers\\TransactionController@pay',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::tzp9BPXDHpbSXFXM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hjHmoikecioe6U2L' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_sale',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::hjHmoikecioe6U2L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dYe7cXEgIxuBWGxP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/food-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@food_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::dYe7cXEgIxuBWGxP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7gl86ceYBQyBBOn8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/drink-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@drinks_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::7gl86ceYBQyBBOn8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pcY0Eu56biVpbIfk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/update-prep-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_prep_status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::pcY0Eu56biVpbIfk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DupRhI3QHAi83Ewv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/banks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'controller' => 'App\\Http\\Controllers\\AuthController@all_banks',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::DupRhI3QHAi83Ewv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U2ScsBEMYz3MYLL6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/get-expiration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'controller' => 'App\\Http\\Controllers\\AuthController@get_expiration',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::U2ScsBEMYz3MYLL6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\AuthController@login',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RjYCvjzimKulKbQU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::RjYCvjzimKulKbQU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5zqpFY17dbFC3j0G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:657:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:438:"function (\\Illuminate\\Http\\Request $request) {
            $user = \\App\\Models\\User::with(\'role\')
            // ->with(\'purchase\')
            // ->with(\'sales\')
            ->with(\'access_log\')
            ->with(\'access_code\')
            ->with(\'shop_access.shop\')
            // ->with(\'expenditure_types\')c
            // ->with(\'expenditure\')
            ->find($request->user()->id);
            return $user;
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"000000000000081c0000000000000000";}";s:4:"hash";s:44:"eO0ieWxg4fpQXGwbyU8sw2A8ekdRXXxRior0OIS/UiY=";}}',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::5zqpFY17dbFC3j0G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CylWEP5ndbqjku1S' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/customer/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'controller' => 'App\\Http\\Controllers\\CustomerController@all_customers',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::CylWEP5ndbqjku1S',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7NE127WdiYBvUYHq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_products',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_products',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::7NE127WdiYBvUYHq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cP9i9b8ATh4DUH68' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::cP9i9b8ATh4DUH68',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_user' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_users',
          3 => 'IaActive',
          4 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_user',
        'controller' => 'App\\Http\\Controllers\\UserController@create_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'create_user',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z65kn29uMv1lCAvf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_users',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@get_user',
        'controller' => 'App\\Http\\Controllers\\UserController@get_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::Z65kn29uMv1lCAvf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::g3WXVDPDQhZjxMnH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_users',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@update_user',
        'controller' => 'App\\Http\\Controllers\\UserController@update_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::g3WXVDPDQhZjxMnH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RWJpHXxxCmhJUpmR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/assign/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_users',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_user_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::RWJpHXxxCmhJUpmR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::64dFvfKzgLXt9Ar3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_users',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_user',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_user',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::64dFvfKzgLXt9Ar3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XigrDj8ffbtUklzu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_users',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_users',
        'controller' => 'App\\Http\\Controllers\\UserController@all_users',
        'namespace' => NULL,
        'prefix' => 'api/v1/user',
        'where' => 
        array (
        ),
        'as' => 'generated::XigrDj8ffbtUklzu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::F8WeCkoFIvXCEuG8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_roles',
        'controller' => 'App\\Http\\Controllers\\UserController@all_roles',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::F8WeCkoFIvXCEuG8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sLT8AkPIPlsHitoi' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/priviledges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'controller' => 'App\\Http\\Controllers\\UserController@all_priviledges',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::sLT8AkPIPlsHitoi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_roles' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
          4 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_role',
        'controller' => 'App\\Http\\Controllers\\UserController@create_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'create_roles',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KBE8THlxKQoaCtXd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/role/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_role',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_role',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::KBE8THlxKQoaCtXd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y1CmQOytAsHsLzll' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@create_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::y1CmQOytAsHsLzll',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::riixGlyFKJZIkOuq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/priviledge/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@delete_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::riixGlyFKJZIkOuq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HYUwayctJcDNaxHM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/assign/role/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@assign_role_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::HYUwayctJcDNaxHM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y2eg0OifqhAMufxJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/role/priviledges/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_roles_priviledges',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\UserController@get_role_priviledge',
        'controller' => 'App\\Http\\Controllers\\UserController@get_role_priviledge',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Y2eg0OifqhAMufxJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_categories' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_categories',
          3 => 'IaActive',
          4 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'create_categories',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NNSMSkdNfkgYnucQ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_categories',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::NNSMSkdNfkgYnucQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dh4kaHErEJnx3zFu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/category/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_categories',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_category',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::Dh4kaHErEJnx3zFu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ScXpCE7gNdsdHA3t' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/category',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_categories',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_categories',
        'namespace' => NULL,
        'prefix' => 'api/v1/category',
        'where' => 
        array (
        ),
        'as' => 'generated::ScXpCE7gNdsdHA3t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_products' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_products',
          3 => 'IaActive',
          4 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@create_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@create_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'create_products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7RaHVw9nK85VIXFQ' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/product/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_products',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::7RaHVw9nK85VIXFQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gnaL7NNjKrWxv53U' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_products',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_product',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::gnaL7NNjKrWxv53U',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qSNEydLO8ON3hxW1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_products',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::qSNEydLO8ON3hxW1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7D6U1PKKw8blFequ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/report/all/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_products',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@general_generate_product_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::7D6U1PKKw8blFequ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zxpIas6r7aobHhQU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/product/upload/image',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_products',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'controller' => 'App\\Http\\Controllers\\ProductController@upload_images',
        'namespace' => NULL,
        'prefix' => 'api/v1/product',
        'where' => 
        array (
        ),
        'as' => 'generated::zxpIas6r7aobHhQU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iVTmqYCXLShtwu9E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@new_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::iVTmqYCXLShtwu9E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uJkteB7nLrO4GB71' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@update_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::uJkteB7nLrO4GB71',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GzncGj9BC8bdug5t' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/detail/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase_detail',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::GzncGj9BC8bdug5t',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BKSwRsaRNlPquyAp' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'controller' => 'App\\Http\\Controllers\\ProductController@delete_purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::BKSwRsaRNlPquyAp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CBfhfBFdLULaPPeC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'controller' => 'App\\Http\\Controllers\\ProductController@all_purchases',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::CBfhfBFdLULaPPeC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xafjPym2VL688wDy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'controller' => 'App\\Http\\Controllers\\ProductController@purchase_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::xafjPym2VL688wDy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eQevlxYzDszJJs8d' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/purchase/update-plan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@updatePaymentPlan',
        'controller' => 'App\\Http\\Controllers\\ProductController@updatePaymentPlan',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase',
        'where' => 
        array (
        ),
        'as' => 'generated::eQevlxYzDszJJs8d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fXF35dFQTYiuFefZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/purchase/documents/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@uploadDocument',
        'controller' => 'App\\Http\\Controllers\\ProductController@uploadDocument',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase/documents',
        'where' => 
        array (
        ),
        'as' => 'generated::fXF35dFQTYiuFefZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CRn2dJI31hxnAQst' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/purchase/documents/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@deleteDocument',
        'controller' => 'App\\Http\\Controllers\\ProductController@deleteDocument',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase/documents',
        'where' => 
        array (
        ),
        'as' => 'generated::CRn2dJI31hxnAQst',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Uqb8uCyM1GSW58vD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/purchase/documents/download/{purchase_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_purchases',
        ),
        'uses' => 'App\\Http\\Controllers\\ProductController@downloadDocuments',
        'controller' => 'App\\Http\\Controllers\\ProductController@downloadDocuments',
        'namespace' => NULL,
        'prefix' => 'api/v1/purchase/documents',
        'where' => 
        array (
        ),
        'as' => 'generated::Uqb8uCyM1GSW58vD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_customers' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_customers',
          3 => 'IaActive',
          4 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@create_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'create_customers',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vw4Tnvl8JyrvXF2Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_customers',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@update_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::Vw4Tnvl8JyrvXF2Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7wADa8PBw6iUVLGJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/fund/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_customers',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@fund_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::7wADa8PBw6iUVLGJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TafexCNeRxAHWXZx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_customers',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'controller' => 'App\\Http\\Controllers\\CustomerController@delete_customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::TafexCNeRxAHWXZx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yLwNepxZf98LyGcI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/customer/details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_customers',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'controller' => 'App\\Http\\Controllers\\CustomerController@customer_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/customer',
        'where' => 
        array (
        ),
        'as' => 'generated::yLwNepxZf98LyGcI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9JoJ6tVGRyZeFKYK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@create_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::9JoJ6tVGRyZeFKYK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TLhPQbH7EXXbFFGW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@update_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::TLhPQbH7EXXbFFGW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tK9btZFpQK3QVwJN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::tK9btZFpQK3QVwJN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jibKs90bEO6ItmiV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::jibKs90bEO6ItmiV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7NCasSxsXgTMNPip' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_discounts',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::7NCasSxsXgTMNPip',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HFYfGHlL1ffdSFps' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/discount/available',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@search_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::HFYfGHlL1ffdSFps',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a27yb1rVK9m3x8lO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/discount/customer/delete/{id}/{discount}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_discounts',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'controller' => 'App\\Http\\Controllers\\TransactionController@delete_customer_discount',
        'namespace' => NULL,
        'prefix' => 'api/v1/discount',
        'where' => 
        array (
        ),
        'as' => 'generated::a27yb1rVK9m3x8lO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ok6wkAs2H7g9vSN9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/sell/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_sales',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@all_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::ok6wkAs2H7g9vSN9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C8swdkYocafwu4Hc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/periodic',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_sales',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@periodic_sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::C8swdkYocafwu4Hc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qyq8uvMXFMvw2J6w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/today',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_sales',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'controller' => 'App\\Http\\Controllers\\TransactionController@sales_report_today',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::Qyq8uvMXFMvw2J6w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qrQkKgmxtnidyiai' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/pod',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_sales',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payondelivery',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::qrQkKgmxtnidyiai',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ka7UsnDl35ugnZum' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/v1/sell/verify/poc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_sales',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'controller' => 'App\\Http\\Controllers\\TransactionController@payoncredit',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::Ka7UsnDl35ugnZum',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o1tpUsmvbel2csj0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/sell/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_sales',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\TransactionController@updateSales',
        'controller' => 'App\\Http\\Controllers\\TransactionController@updateSales',
        'namespace' => NULL,
        'prefix' => 'api/v1/sell',
        'where' => 
        array (
        ),
        'as' => 'generated::o1tpUsmvbel2csj0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z3QqdRv85ibqjEmU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::z3QqdRv85ibqjEmU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DToI0TQtqdIyTVzg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_business_details',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::DToI0TQtqdIyTVzg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4uTBJPs5yVHkuYuC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/expire',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@expire',
        'controller' => 'App\\Http\\Controllers\\AuthController@expire',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::4uTBJPs5yVHkuYuC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::W1vhNTCLliAaaWzy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/business/restore',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@restore',
        'controller' => 'App\\Http\\Controllers\\AuthController@restore',
        'namespace' => NULL,
        'prefix' => 'api/v1/business',
        'where' => 
        array (
        ),
        'as' => 'generated::W1vhNTCLliAaaWzy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KCZRkl7N6CKKaHdx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/new',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@new_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@new_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::KCZRkl7N6CKKaHdx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yEBpN88Cc2jcz5bW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/activation/activate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@use_code',
        'controller' => 'App\\Http\\Controllers\\AuthController@use_code',
        'namespace' => NULL,
        'prefix' => 'api/v1/activation',
        'where' => 
        array (
        ),
        'as' => 'generated::yEBpN88Cc2jcz5bW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vATf8yPgv8dFE6g0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::vATf8yPgv8dFE6g0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8Uzz6fbaNp72ec5B' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_type',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::8Uzz6fbaNp72ec5B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pWlRJzUVzt3VCRR4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/type/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::pWlRJzUVzt3VCRR4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vgrsmbvEf3CCk7wU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure/type',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_types',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::vgrsmbvEf3CCk7wU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_expenditures' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
          4 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@new_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'create_expenditures',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::D8Uj4QP3ApOULnjn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@update_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::D8Uj4QP3ApOULnjn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MM5HbHPGiFumx4DF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@delete_expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::MM5HbHPGiFumx4DF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rrjmRuUJ2PHiiG2b' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@all_expenditures',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::rrjmRuUJ2PHiiG2b',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ElEHooqtiQizR7Fg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@report',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::ElEHooqtiQizR7Fg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::29IBU09359wE6o6f' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/expenditure/update-plan/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@updateExpenditurPaymentPlan',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@updateExpenditurPaymentPlan',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure',
        'where' => 
        array (
        ),
        'as' => 'generated::29IBU09359wE6o6f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5tqxMt2SgY4SIKUH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/expenditure/documents/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@uploadDocument',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@uploadDocument',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure/documents',
        'where' => 
        array (
        ),
        'as' => 'generated::5tqxMt2SgY4SIKUH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::M1Hf5K6TLUjvB9CK' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/expenditure/documents/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@deleteDocument',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@deleteDocument',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure/documents',
        'where' => 
        array (
        ),
        'as' => 'generated::M1Hf5K6TLUjvB9CK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zHpTN9Eu4cHLcXiv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/expenditure/documents/download/{purchase_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_expenditure',
        ),
        'uses' => 'App\\Http\\Controllers\\ExpenditureController@downloadDocuments',
        'controller' => 'App\\Http\\Controllers\\ExpenditureController@downloadDocuments',
        'namespace' => NULL,
        'prefix' => 'api/v1/expenditure/documents',
        'where' => 
        array (
        ),
        'as' => 'generated::zHpTN9Eu4cHLcXiv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YLgOBsiiwUDXd2Du' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/budget/create-budget',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_budget',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\BudgetController@storeBulk',
        'controller' => 'App\\Http\\Controllers\\BudgetController@storeBulk',
        'namespace' => NULL,
        'prefix' => 'api/v1/budget',
        'where' => 
        array (
        ),
        'as' => 'generated::YLgOBsiiwUDXd2Du',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MqAn8EkiCNgP8zoO' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/budget/delete-budget/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_budget',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\BudgetController@destroy',
        'controller' => 'App\\Http\\Controllers\\BudgetController@destroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/budget',
        'where' => 
        array (
        ),
        'as' => 'generated::MqAn8EkiCNgP8zoO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LdM83hSeXBuv5DYQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/budget/show-budget',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_budget',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\BudgetController@showPeriodically',
        'controller' => 'App\\Http\\Controllers\\BudgetController@showPeriodically',
        'namespace' => NULL,
        'prefix' => 'api/v1/budget',
        'where' => 
        array (
        ),
        'as' => 'generated::LdM83hSeXBuv5DYQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NGrTkJXwUtShIJSF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/budget/update-budget/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_budget',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\BudgetController@update',
        'controller' => 'App\\Http\\Controllers\\BudgetController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/budget',
        'where' => 
        array (
        ),
        'as' => 'generated::NGrTkJXwUtShIJSF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DDtIzwuhA43xdno1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@general_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@general_report',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::DDtIzwuhA43xdno1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::njr4PIY0JmPDRuQy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/deleted',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'controller' => 'App\\Http\\Controllers\\ReportController@cancelled_receipt',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::njr4PIY0JmPDRuQy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gB25as9kIdPLl3ma' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/sales-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getSalesPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::gB25as9kIdPLl3ma',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i6HKTJzud2xju8Zr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/opex-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getOpexPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::i6HKTJzud2xju8Zr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uBniWhdY9siiDrPu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/report/debt-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCustomerInsightPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::uBniWhdY9siiDrPu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VpKgmGNkX2Iuc7Ad' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/cogs-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'controller' => 'App\\Http\\Controllers\\ReportController@getCogs',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::VpKgmGNkX2Iuc7Ad',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pfciqAfJU72chQu5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/method-performance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getPaymentMethodPerformance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::pfciqAfJU72chQu5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MRco5Rk1PYgbeRI0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/profit-loss',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'controller' => 'App\\Http\\Controllers\\ReportController@getProfitLoss',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::MRco5Rk1PYgbeRI0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hOgQYU4DXkl9p3cj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/report/bank-balance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getBankAccountBalance',
        'controller' => 'App\\Http\\Controllers\\ReportController@getBankAccountBalance',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::hOgQYU4DXkl9p3cj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vzd3V2PM1HXlM43E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/bank-statement',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getBankStatement',
        'controller' => 'App\\Http\\Controllers\\ReportController@getBankStatement',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::Vzd3V2PM1HXlM43E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FRTrnWuahm8OfEBy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/logistics-statement',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getLogisticsStatement',
        'controller' => 'App\\Http\\Controllers\\ReportController@getLogisticsStatement',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::FRTrnWuahm8OfEBy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E8WNsCJ2ce7KIjL4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/payables',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@getPayables',
        'controller' => 'App\\Http\\Controllers\\ReportController@getPayables',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::E8WNsCJ2ce7KIjL4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gsg3NycheBPkGUBw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/report/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_view_reports',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@downloadReport',
        'controller' => 'App\\Http\\Controllers\\ReportController@downloadReport',
        'namespace' => NULL,
        'prefix' => 'api/v1/report',
        'where' => 
        array (
        ),
        'as' => 'generated::gsg3NycheBPkGUBw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'sales' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/backend/sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_backend',
        ),
        'uses' => 'App\\Http\\Controllers\\BackendController@sales',
        'controller' => 'App\\Http\\Controllers\\BackendController@sales',
        'namespace' => NULL,
        'prefix' => 'api/v1/backend',
        'where' => 
        array (
        ),
        'as' => 'sales',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'purchases' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/backend/purchases',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_backend',
        ),
        'uses' => 'App\\Http\\Controllers\\BackendController@purchases',
        'controller' => 'App\\Http\\Controllers\\BackendController@purchases',
        'namespace' => NULL,
        'prefix' => 'api/v1/backend',
        'where' => 
        array (
        ),
        'as' => 'purchases',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/backend/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_backend',
        ),
        'uses' => 'App\\Http\\Controllers\\BackendController@products',
        'controller' => 'App\\Http\\Controllers\\BackendController@products',
        'namespace' => NULL,
        'prefix' => 'api/v1/backend',
        'where' => 
        array (
        ),
        'as' => 'products',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'expenditure' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/backend/expenditure',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_backend',
        ),
        'uses' => 'App\\Http\\Controllers\\BackendController@expenditure',
        'controller' => 'App\\Http\\Controllers\\BackendController@expenditure',
        'namespace' => NULL,
        'prefix' => 'api/v1/backend',
        'where' => 
        array (
        ),
        'as' => 'expenditure',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'staff' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/backend/staff',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_backend',
        ),
        'uses' => 'App\\Http\\Controllers\\BackendController@staff',
        'controller' => 'App\\Http\\Controllers\\BackendController@staff',
        'namespace' => NULL,
        'prefix' => 'api/v1/backend',
        'where' => 
        array (
        ),
        'as' => 'staff',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'customer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/backend/customer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_backend',
        ),
        'uses' => 'App\\Http\\Controllers\\BackendController@customer',
        'controller' => 'App\\Http\\Controllers\\BackendController@customer',
        'namespace' => NULL,
        'prefix' => 'api/v1/backend',
        'where' => 
        array (
        ),
        'as' => 'customer',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sRcoFUGc4HK5xdkW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/store',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_banks',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@create_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::sRcoFUGc4HK5xdkW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ctN5kKiNw3AXqGJX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_banks',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@update_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::ctN5kKiNw3AXqGJX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SrNKkd99vTIokElS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/banks/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'checkPermission:can_manage_banks',
          3 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'controller' => 'App\\Http\\Controllers\\AuthController@delete_bank',
        'namespace' => NULL,
        'prefix' => 'api/v1/banks',
        'where' => 
        array (
        ),
        'as' => 'generated::SrNKkd99vTIokElS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZXw4hCmFLmvg4H4O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/generate-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'controller' => 'App\\Http\\Controllers\\AuthController@generate_user_codes',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZXw4hCmFLmvg4H4O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SV63nbCsDTkJae51' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/transaction-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::SV63nbCsDTkJae51',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::W8pTwV7CKwn2SZ3W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user-transaction-report/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_user_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_user_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::W8pTwV7CKwn2SZ3W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tQNckeO0esZc7saW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/user-sales-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
        ),
        'uses' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'controller' => 'App\\Http\\Controllers\\ReportController@generate_sales_report',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::tQNckeO0esZc7saW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XVP35NMJwkBvYBhE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/shop/all',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@index',
        'controller' => 'App\\Http\\Controllers\\ShopController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::XVP35NMJwkBvYBhE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'create_branches' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/shop/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
          4 => 'IaActive',
          5 => 'CheckPackagePlan',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@create',
        'controller' => 'App\\Http\\Controllers\\ShopController@create',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'create_branches',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OieRHk8sBi6wPT8f' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/shop/assign/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@assign',
        'controller' => 'App\\Http\\Controllers\\ShopController@assign',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::OieRHk8sBi6wPT8f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5ZJJfE9uSBnOrXYD' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/shop/update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@update',
        'controller' => 'App\\Http\\Controllers\\ShopController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::5ZJJfE9uSBnOrXYD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SHY47bBGSoD8MUSu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/shop/one/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@show',
        'controller' => 'App\\Http\\Controllers\\ShopController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::SHY47bBGSoD8MUSu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gEGD5dZmNoDfCB9x' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/shop/delete/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@delete',
        'controller' => 'App\\Http\\Controllers\\ShopController@delete',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::gEGD5dZmNoDfCB9x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wCT3CANFlIsMisPh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/shop/initiate-transfer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@transferProduct',
        'controller' => 'App\\Http\\Controllers\\ShopController@transferProduct',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::wCT3CANFlIsMisPh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::25KvgTd5NdyXTHUU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/shop/approve-transfer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@approveTransfer',
        'controller' => 'App\\Http\\Controllers\\ShopController@approveTransfer',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::25KvgTd5NdyXTHUU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WDMfU29V55ZsEWjL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/shop/reject-transfer/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@rejectTransfer',
        'controller' => 'App\\Http\\Controllers\\ShopController@rejectTransfer',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::WDMfU29V55ZsEWjL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HbVqD2g45vy8xgZh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/shop/recent-transfers/{shopId}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'IaActive',
          3 => 'checkPermission:can_manage_shops',
        ),
        'uses' => 'App\\Http\\Controllers\\ShopController@recentTransfers',
        'controller' => 'App\\Http\\Controllers\\ShopController@recentTransfers',
        'namespace' => NULL,
        'prefix' => 'api/v1/shop',
        'where' => 
        array (
        ),
        'as' => 'generated::HbVqD2g45vy8xgZh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'goods_delivery_notes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/goods_delivery_notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\GoodDeliverNoteController@index',
        'controller' => 'App\\Http\\Controllers\\GoodDeliverNoteController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/goods_delivery_notes',
        'where' => 
        array (
        ),
        'as' => 'goods_delivery_notes.index',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'goods_delivery_notes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/goods_delivery_notes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\GoodDeliverNoteController@store',
        'controller' => 'App\\Http\\Controllers\\GoodDeliverNoteController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/goods_delivery_notes',
        'where' => 
        array (
        ),
        'as' => 'goods_delivery_notes.store',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'goods_delivery_notes.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/goods_delivery_notes/{goodsDeliveryNote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\GoodDeliverNoteController@show',
        'controller' => 'App\\Http\\Controllers\\GoodDeliverNoteController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/goods_delivery_notes',
        'where' => 
        array (
        ),
        'as' => 'goods_delivery_notes.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'goods_delivery_notes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/goods_delivery_notes/{goodsDeliveryNote}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\GoodDeliverNoteController@update',
        'controller' => 'App\\Http\\Controllers\\GoodDeliverNoteController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/goods_delivery_notes',
        'where' => 
        array (
        ),
        'as' => 'goods_delivery_notes.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'goods_delivery_notes.download' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/goods_delivery_notes/{goodsDeliveryNote}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'App\\Http\\Controllers\\GoodDeliverNoteController@download',
        'controller' => 'App\\Http\\Controllers\\GoodDeliverNoteController@download',
        'namespace' => NULL,
        'prefix' => 'api/v1/goods_delivery_notes',
        'where' => 
        array (
        ),
        'as' => 'goods_delivery_notes.download',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sheV9Eu0m3fjoKHw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:264:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:46:"function () {
    return \\view(\'welcome\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000008050000000000000000";}";s:4:"hash";s:44:"f4aXONvXsi3sjp+OTu5dTzM05ezfcgiyr6q0N/Ktltw=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::sheV9Eu0m3fjoKHw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
